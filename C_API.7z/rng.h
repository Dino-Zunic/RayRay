#pragma once
#include "real.h"

void rng_srand(unsigned int s);
real rng_rand();
