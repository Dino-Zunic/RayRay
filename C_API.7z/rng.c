#include "rng.h"

static int seed;

void rng_init() {
    seed = 1;
}

void rng_srand(unsigned int s) {
    seed = s;
}

real rng_rand() {
    seed = (214013 * seed + 2531011) & 0x7FFFFFFF;
    return real_float(seed / 2147483648.0f);
}
