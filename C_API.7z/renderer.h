#pragma once

#include "scene.h"

extern vec3 renderer_canvas[CAMERA_HEIGHT][CAMERA_WIDTH];

void renderer_render();
