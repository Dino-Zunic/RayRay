#pragma once

#include "sphere.h"
#include "rng.h"
#include "camera.h"
#include "material.h"

#define MAX_DEPTH 5                     //MAX_DEPTH - koliko puta pratimo odbijanje zraka
#define MAX_SPHERES 50
#define SCENE_SPAWN_DISTANCE 0x00010000

extern sphere scene_spheres[MAX_SPHERES];
extern real * const scene_ghost_radius;
extern int * const scene_ghost_mode;
extern int * const scene_num_of_spheres;
extern sphere ** const scene_marked_sphere_address;

real scene_clamp_real(real x);
vec3 scene_clamp_vec3(const vec3 *color);
int scene_intersect_plane(const ray *r, real *t);
vec3 scene_get_floor_color(const vec3 *point, real t);
vec3 scene_trace_ray(const ray *r, int depth);
void scene_reset();
vec3 get_sky_color(const ray *r);
void scene_add_sphere(const vec3 *position, real radius);
void scene_remove_sphere(sphere *sp);
