#include "renderer.h"
#include "material.h"
#include <math.h>
#include <stdlib.h>

vec3 renderer_canvas[CAMERA_HEIGHT][CAMERA_WIDTH];


static void renderer_sort_spheres(const sphere *spheres[], int num_of_spheres) {
    int pos = num_of_spheres;
    while (pos != 0) {
        int bound = pos;
        vec3 temp;
        pos = 0;
        for (int i = 0; i < bound - 1; i++) {
            vec3 temp;
            temp = vec3_subtract(&spheres[i]->center, camera_position);
            real dist1 = vec3_length2(&temp);
            temp = vec3_subtract(&spheres[i + 1]->center, camera_position);
            real dist2 = vec3_length2(&temp);
            if (dist1 < dist2) {
                const sphere *temp = spheres[i];
                spheres[i] = spheres[i + 1];
                spheres[i + 1] = temp;
                pos = i + 1;
            }
        }
    }
}


static void renderer_solveQuadratic(float a, float b, float c, real *xMin, real *xMax) {
    if (a == 0) {
        *xMin = *xMax = real_float(-c / b);
        return;
    }
    float discriminant = b * b - 4 * a * c;
    float delta = sqrtf(discriminant);
    if (a > 0) {
        *xMin = real_float((-b - delta) / 2 / a);
        *xMax = real_float((-b + delta) / 2 / a);
    }
    else {
        *xMin = real_float((-b + delta) / 2 / a);
        *xMax = real_float((-b - delta) / 2 / a);
    }
}

static void renderer_calculate_bounds_x(real a, real b, real c, real A, real *x_min, real *x_max) {
    float a_ = float_real(a), b_ = float_real(b), c_ = float_real(c), A_ = float_real(A);
    float a2_ = a_ * a_, b2_ = b_ * b_, c2_ = c_ * c_;
    renderer_solveQuadratic(
        a2_ * b2_ - (b2_ - A_) * (a2_ - A_),
        2 * a_ * c_ * A_,
        b2_ * c2_ - (b2_ - A_) * (c2_ - A_),
        x_min,
        x_max
    );
}

static void rendered_render_sphere_projected(const sphere *s) {
    vec3 c = s->center;

    if (c.z < 0) {
        return;
    }

    real A = vec3_length2(&c) - real_mul(s->radius, s->radius);

    real x_min, x_max, y_min, y_max;
    renderer_calculate_bounds_x(c.x, c.y, c.z, A, &x_min, &x_max);
    renderer_calculate_bounds_x(c.y, c.x, c.z, A, &y_min, &y_max);

    int i_min = int_real(y_min * CAMERA_HEIGHT) + CAMERA_HEIGHT / 2;
    int i_max = int_real(y_max * CAMERA_HEIGHT) + CAMERA_HEIGHT / 2;
    int j_min = int_real(x_min * CAMERA_HEIGHT) + CAMERA_WIDTH / 2;
    int j_max = int_real(x_max * CAMERA_HEIGHT) + CAMERA_WIDTH / 2;

    if (i_min < 0) { i_min = 0; }
    if (j_min < 0) { j_min = 0; }
    if (i_max > CAMERA_HEIGHT - 1) { i_max = CAMERA_HEIGHT - 1; }
    if (j_max > CAMERA_WIDTH - 1) { j_max = CAMERA_WIDTH - 1; }

    if (1) { i_min = 0; }
    if (1) { j_min = 0; }
    if (1) { i_max = CAMERA_HEIGHT - 1; }
    if (1) { j_max = CAMERA_WIDTH - 1; }

    for (int y = i_min; y <= i_max; y++) {
        for (int x = j_min; x <= j_max; x++) {
            const real rx = (x - 400) << 7;
            const real ry = (y - 300) << 7;
            const real temp1 = real_mul(c.x, rx) + real_mul(c.y, ry) + c.z;
            if (real_mul(temp1, temp1) >= real_mul(A, real_mul(rx, rx) + real_mul(ry, ry) + 0x00010000)) {
                renderer_canvas[y][x] = s->mat.color;
            }
        }
    }
}

static void renderer_render_sphere(const sphere *s) {
    vec3 camera_to_sphere = vec3_subtract(&s->center, camera_position);
    vec3 c = vec3_init_values(
        vec3_dot(&camera_to_sphere, camera_right),
        vec3_dot(&camera_to_sphere, camera_up),
        vec3_dot(&camera_to_sphere, camera_forward)
    );
    sphere projected = sphere_init_with_values(c, s->radius, s->mat);
    rendered_render_sphere_projected(&projected);
}

static void renderer_render_floor() {
    vec3 floor_color = material_color_floor1[material_light_mode];
    real c = *camera_cos_pitch;
    real s = *camera_sin_pitch;
    for (int y = 0; y < CAMERA_HEIGHT; y++) {
        for (int x = 0; x < CAMERA_WIDTH; x++) {
            if (c * (299 - y) > (s << 9)) {
                renderer_canvas[y][x] = floor_color;
            }
        }
    }
}

void renderer_render() {
    const sphere *spheres[MAX_SPHERES];
    int num_of_spheres = *scene_num_of_spheres;
    for (int i = 0; i < num_of_spheres; i++) {
        spheres[i] = &scene_spheres[i];
    }
    renderer_sort_spheres(spheres, num_of_spheres);
    vec3 sky_color = material_color_sky[material_light_mode];
    for (int i = 0; i < CAMERA_HEIGHT; i++) {
        for (int j = 0; j < CAMERA_WIDTH; j++) {
            renderer_canvas[i][j] = sky_color;
        }
    }
    renderer_render_floor();
    for (int i = 0; i < num_of_spheres; i++) {
        if (spheres[i] == *scene_marked_sphere_address) {
            sphere s = *spheres[i];
            s.mat.color = material_color_rgb(0xff0000);
            renderer_render_sphere(&s);
        }
        else {
            renderer_render_sphere(spheres[i]);
        }
    }
    if (*scene_ghost_mode) {
        sphere ghost_projected = sphere_init_with_values(
            vec3_init_values(0, 0, SCENE_SPAWN_DISTANCE + *scene_ghost_radius),
            *scene_ghost_radius, 
            material_init_with_values(material_color_rgb(0xFF0000), 0x00010000)
        );
        rendered_render_sphere_projected(&ghost_projected);
    }
}
