#pragma once
extern "C" {
#include "vec3.h"
#include "rng.h"
#include "real.h"
#include "material.h"
#include "camera.h"
#include "scene.h"
#include "renderer.h"
}
